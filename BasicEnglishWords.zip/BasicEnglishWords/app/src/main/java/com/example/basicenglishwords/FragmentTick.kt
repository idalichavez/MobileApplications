package com.example.basicenglishwords

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_blank.*
import java.util.*

class FragmentTick : Fragment(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(activity, this)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        val v = inflater.inflate(R.layout.fragment_tick, container, false)
        val btH = v.findViewById<Button>(R.id.btnListen)
        tts = TextToSpeech(activity, this)
        btH.setOnClickListener {

            tts!!.speak("tick", TextToSpeech.QUEUE_FLUSH, null, "")
        }


        return v

    }


   override fun onInit(status: Int) {
       if (status == TextToSpeech.SUCCESS) {

           // set US English as language for tts
           val result = tts!!.setLanguage(Locale.US)

           if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
               Log.e("TTS","The Language specified is not supported!")
           } else {
               this.btnListen.isEnabled = true
           }

       } else {
           Log.e("TTS", "Initilization Failed!")
       }

   }


}