package com.example.basicenglishwords
//This activity shows general information about the app.
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import kotlinx.android.synthetic.main.help.*

class Help  : AppCompatActivity()

    {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.help)
            txtHelp.text = "Basic English Words 1.0 (Demo Level 1)"
            txtDescription.text = "This application helps Beginner Level English Learners to practice basic words. You can read words, listen them and practice them in the game."
            txtPreferences.text =        "Go to Preferences to set up your information or to Reset your Score."

        }

        //add menu.
        override fun onCreateOptionsMenu(menu: Menu):Boolean{
            menuInflater.inflate(R.menu.train0, menu)
            return true
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            when (item?.itemId) {

                R.id.main -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    return super.onOptionsItemSelected(item)
                }
                else ->
                    return super.onOptionsItemSelected(item)

            }
        }

    }
