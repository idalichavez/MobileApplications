package com.example.basicenglishwords
//Basic English Word (Demo)
/*This application help English Learners to memorize lists of basic words.
* This demo contains the level 1 list.
* Author: Idali Chavez Pacheco
* Last Revision: 05/14/2021
* */

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.preferences.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       //Shared preferences are displayed in Main Screen if they are configured.
        var databack: SharedPreferences = getSharedPreferences("myPrefs", 0)
        if (databack.contains("message")) {
            txtMain.text = "Hello " + databack.getString("message", "not found")
        } else txtMain.text = "Hello "

        var databackRecord: SharedPreferences = getSharedPreferences("Record", 0)
        if (databackRecord.contains("message")) {
            txtMainScore.text = "Your record is " + databackRecord.getString("message", "not found")
        } else {
            txtMainScore.text = "Your record is 0"

        }

    }

    //Go to Activitiesc
    fun Go2trainingActivity(view: View){
        startActivity(Intent(this, TrainingActivity::class.java))
    }

    fun Go2Preferences(view: View){
        startActivity(Intent(this, Preferences::class.java))
    }

    fun Go2Help(view: View){
        startActivity(Intent(this, Help::class.java))
    }

    fun Go2Spelling(view:View){
        startActivity(Intent(this, SpellingGame::class.java))
    }

    fun Go2Training2(view:View){
        startActivity(Intent(this, Training2::class.java))
    }
}