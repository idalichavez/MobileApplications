package com.example.basicenglishwords
//This activity checks spelling by showing images and prompting the user to type the words.
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.fragment.app.findFragment
import kotlinx.android.synthetic.main.activity_spelling_game.*
import kotlinx.android.synthetic.main.preferences.*

class SpellingGame : AppCompatActivity() {

    public var gameScore = 0
    var i = 0
    var spellingList: Array<String> = arrayOf("sick","in","tick","thin","lick","him","kick","hit")
    var imageList: Array<Int> = arrayOf(R.drawable.sick,R.drawable.`in` ,R.drawable.tick, R.drawable.thin, R.drawable.lick,R.drawable.him, R.drawable.kick,R.drawable.hit )
    var myRecord: SharedPreferences?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spelling_game)

        imgSpelling.setImageResource(imageList[0])

    btnSpelling.setOnClickListener {


        if (edtSpelling.text.toString() == spellingList[i]){
            Toast.makeText(applicationContext, "Correct!! You win 10 points.", Toast.LENGTH_SHORT).show()
            gameScore += 10
            txtSscore.setText(gameScore.toString())
        }
            else{
            Toast.makeText(applicationContext, "Incorrect!!", Toast.LENGTH_SHORT).show()}

        if (i != 7) {
             i++
            imgSpelling.setImageResource(imageList[i])
            edtSpelling.setText(null)
        }
        else {
            btnSpelling.isEnabled = false
            myRecord=getSharedPreferences("Record",0)

            var editor: SharedPreferences.Editor = (myRecord as SharedPreferences).edit()
            if (gameScore !=0){
                    //(!TextUtils.isEmpty(txtFirstName.text.toString())) {
                editor.putString("message", gameScore.toString())
                editor.commit()
            }


            Toast.makeText(applicationContext, "END OF GAME", Toast.LENGTH_SHORT).show()
        }

        }
    }
        //add menu.
        override fun onCreateOptionsMenu(menu: Menu):Boolean{
            menuInflater.inflate(R.menu.train, menu)
            return true
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            when (item?.itemId) {
                R.id.action_settings -> {
                    startActivity(Intent(this, Help::class.java))
                    return super.onOptionsItemSelected(item)
                }
                R.id.main -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    return super.onOptionsItemSelected(item)
                }
                else ->
                    return super.onOptionsItemSelected(item)

            }
        }


}