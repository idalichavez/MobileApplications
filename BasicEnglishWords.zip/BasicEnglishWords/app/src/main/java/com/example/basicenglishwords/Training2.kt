package com.example.basicenglishwords
//This activity shows fragments that allow the user to listen to the words.
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem

class Training2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_training2)

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.train, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, Help::class.java))
                return super.onOptionsItemSelected(item)
            }
            R.id.main -> {
                startActivity(Intent(this, MainActivity::class.java))
                return super.onOptionsItemSelected(item)
            }
            else ->
                return super.onOptionsItemSelected(item)

        }
    }
}