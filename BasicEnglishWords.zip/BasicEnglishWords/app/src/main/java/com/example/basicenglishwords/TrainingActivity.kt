package com.example.basicenglishwords

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.core.view.get
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.basicenglishwords.data.WordListAdapter
import com.example.basicenglishwords.model.words10
import kotlinx.android.synthetic.main.activity_training.*
import kotlinx.android.synthetic.main.activity_training.view.*

private var adapter:WordListAdapter?=null
private var wordyList: ArrayList<words10>?=null
private var layoutManager: RecyclerView.LayoutManager?=null


// This activity trains the user to learn a list of 10 words.
//PENDING: Add sound and images to the list.

class TrainingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_training)
        wordyList = ArrayList<words10>()
        layoutManager= LinearLayoutManager(this)
        adapter = WordListAdapter(wordyList!!,this)

        myRecyclerView.layoutManager = layoutManager
        myRecyclerView.adapter= adapter

        var wordNameList: Array<String> = arrayOf("sick","in","tick","thick","thin","lick","him","kick","hit","is")
        var defNameList: Array<String> = arrayOf("sik","in","tik","THik","THin","lik","him","kik","hit","is")
        for (i in 0..9) {
            var word =words10()
            word.Word = wordNameList[i]
            word.Pronunciation = defNameList [i]
            wordyList?.add(word)
        }
        adapter!!.notifyDataSetChanged()


    }

    //add menu.
    override fun onCreateOptionsMenu(menu: Menu):Boolean{
        menuInflater.inflate(R.menu.train, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, Help::class.java))
                return super.onOptionsItemSelected(item)
            }
            R.id.main -> {
                startActivity(Intent(this, MainActivity::class.java))
                return super.onOptionsItemSelected(item)
            }
            else ->
                return super.onOptionsItemSelected(item)

        }
    }
}


