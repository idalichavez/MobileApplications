package com.example.basicenglishwords.data

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.basicenglishwords.R
import com.example.basicenglishwords.model.words10


class WordListAdapter(private val list: ArrayList<words10>, private val context: Context): RecyclerView.Adapter<WordListAdapter.ViewHolder>() {



    override fun onBindViewHolder(holder: WordListAdapter.ViewHolder, position: Int) {
        holder.bindItem(list[position])




    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.word_layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItem(word: words10) {
            var wordy: TextView = itemView.findViewById(R.id.wordy_ID) as TextView
            var worddef: TextView = itemView.findViewById(R.id.worddef_ID) as TextView
            var imaget: ImageView = itemView.findViewById(R.id.imageTrain) as ImageView

            wordy.text = word.Word
            worddef.text = word.Pronunciation



            itemView.setOnClickListener {
                Toast.makeText(context, wordy.text, Toast.LENGTH_SHORT).show()
                }

        }



    }



}











