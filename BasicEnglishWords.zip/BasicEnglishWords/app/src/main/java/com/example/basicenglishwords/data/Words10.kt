package com.example.basicenglishwords.model

import android.media.Image
import android.widget.ImageView

class words10 {

    var Word: String?=null
    var Pronunciation: String?=null
    var IconTrain: ImageView?=null

}