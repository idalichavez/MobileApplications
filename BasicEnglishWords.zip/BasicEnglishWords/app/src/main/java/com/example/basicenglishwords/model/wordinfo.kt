package com.example.basicenglishwords.model

class wordinfo {
}